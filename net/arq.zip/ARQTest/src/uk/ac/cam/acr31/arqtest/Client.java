package uk.ac.cam.acr31.arqtest;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Client {
	private InetAddress serverAddress;
	private int serverPort;

	public Client(InetAddress serverAddress, int serverPort) {
		super();
		this.serverAddress = serverAddress;
		this.serverPort = serverPort;
	}
	
	public void run(DatagramSocket socket) throws IOException {
		for(int i=0;i<5;++i) {
			String message = "Message "+i;
			new DataPacket(serverAddress, serverPort, message).send(socket);
		}
	}
	
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		int clientPort = Integer.parseInt(args[0]);
		InetAddress serverAddress = InetAddress.getByName(args[1]);
		int serverPort = Integer.parseInt(args[2]);
		double lossProbability = Double.parseDouble(args[3]);
		long propagationTimeMillis = Long.parseLong(args[4]);

		DatagramSocket socket = new TestDatagramSocket(clientPort,
				lossProbability, propagationTimeMillis);

		Client c = new Client(serverAddress, serverPort);
		c.run(socket);
	}
}
