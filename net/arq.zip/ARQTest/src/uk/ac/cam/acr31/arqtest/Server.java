package uk.ac.cam.acr31.arqtest;

import java.io.IOException;
import java.net.DatagramSocket;

public class Server {

	public void run(DatagramSocket s) throws IOException, InterruptedException {
		while (true) {
			DataPacket p = DataPacket.receive(s);
			System.out.println(p.getPayload());
		}
	}

	public static void main(String[] args) throws IOException,
			InterruptedException {
		int serverPort = Integer.parseInt(args[0]);
		double lossProbability = Double.parseDouble(args[1]);
		long propagationTimeMillis = Long.parseLong(args[2]);

		DatagramSocket socket = new TestDatagramSocket(serverPort,
				lossProbability, propagationTimeMillis);

		Server s = new Server();
		s.run(socket);
	}

}
